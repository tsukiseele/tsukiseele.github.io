
import { defuFn } from 'D:/Download/tsukiseele.github.io/node_modules/defu/dist/defu.mjs'

const inlineConfig = {}



export default /* #__PURE__ */ defuFn(inlineConfig)
