import { ComputedRef, Ref } from 'vue'
export type LayoutKey = "blank" | "default" | "error"
declare module "D:/Download/tsukiseele.github.io/node_modules/nuxt/dist/pages/runtime/composables" {
  interface PageMeta {
    layout?: false | LayoutKey | Ref<LayoutKey> | ComputedRef<LayoutKey>
  }
}