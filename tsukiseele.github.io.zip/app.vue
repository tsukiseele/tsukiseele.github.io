<template lang="pug">
NuxtLayout
  NuxtPage
</template>
