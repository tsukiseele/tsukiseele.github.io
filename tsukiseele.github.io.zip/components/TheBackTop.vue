<template lang="pug">
img#back-top(v-if='!isMobile', ref='back', :src='img', :class='{ hide: scroll && scroll.pos < 500 }', @click='handleBackTop()', draggable='false', oncontextmenu='return false')
</template>

<script>
import { mapState } from 'pinia'
export default {
  data: () => ({
    img: `${this.$src}/assets/back-top.png`,
  }),
  computed: {
    ...mapState(['scroll', 'isMobile']),
  },
  methods: {
    handleBackTop() {
      document.getElementById('app').scrollIntoView()
    },
  },
}
</script>

<style lang="scss" scoped>


#back-top {
  position: fixed;
  right: 2rem;
  bottom: 33%;
  transition: bottom 0.3s ease;
  animation: float 3s linear infinite;
  cursor: pointer;
  z-index: 9;
  user-select: none;
  &.hide {
    bottom: 100%;
    animation: none;
  }
  @media screen and (max-width: $mobile) {
    display: none;
  }
}
@keyframes float {
  0% {
    -webkit-transform: translateY(0);
    transform: translateY(0);
  }
  50% {
    -webkit-transform: translateY(-6px);
    transform: translateY(-6px);
  }
  100% {
    -webkit-transform: translateY(0);
    transform: translateY(0);
  }
}
</style>
