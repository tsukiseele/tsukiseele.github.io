<template lang="pug">
Nuxt
</template>