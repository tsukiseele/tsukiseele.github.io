export default () => {
  const ascii = `%c
             ,i::,,,,,,,,,,,,,,,,,,,,,,,,,.     ,iiiiiiiiii;;
         ...:i;:::::::::::::::::::::::::::,    .:ffttttttttii
::ittiii;;;;:::::::::::::::::::::::::ii::::::::::ttftttttttii
;;i::::::::::::::::::::::::::::::::::::iii:::::::::fftttttttt
::ttfii::::::::::;::::::::::::::::::::::::ii::::::::;jtttttff
::ttttt::::::::;;i:::::::::::;;i::::i;:::::;tt:::::::;tt;;i::
::tttii::::::::;;t:::::::::::::i;:::it::::::iii:::::::iii::::
::ttt::::::::::iit:::::::::::::;f;:::ij;;:::::it::::::::tf:::
::tti:::::;;:::fft::::::::::::::ij::::tLLi:::::fi::::::::jf::
,,;f:::::;;;:::jjf:::::::::::::::tjj:::ffLf;::;ti;;;ti:::iLtt
  ;t:::::iii:::jjf;:::::::::::::::jjt::;;t:ittti;..,;t;;::fLL
  :t:::::tii:::fff;:::::::::::::::fff;:::t,,::;ii::;if::::fLL
   ;::::;tii:::ttt;:::::::::::::::;;tt;::;;.....:jjjftii;itGG
   ;::::;fii:::tt;i;;;:::::::::;::;;i,t;;:i......;;tfffft;;LL
   ,;:::;ftt:::ff;;ttti::::::::;;:;;;.,ii;i.....,iijt::::::jj
   .i:::;fff:::ff:.iiif::::::::;i:;;;..::ii...iLEEEEt::::::ff
    i::::tGG;::tt,..::ttii::::::iijji.:::fEWWWDji;;;i::::::ii
    .ii::iLLj;:;;:....:i;;t;;::::ttt.,;DDDi....,,;;ii;iit::::
     ::;::ttjffii:.....:ii,.;tti;:,,...........,:ttiti;;:::::
     ..i::::ti,,,;tjGGGLff,........................,;i;;:::::
       i::::tt;LLKW###WKGG;........................:;i;;::;::
       :i:::iGGtt:,..................,,,,........,,if;:::;i::
        tt::;ffttt:,............:tffti;;;i,......,,;j;:::;t;;
        ;fiitiiiii:............;jtii:::::::.....,ffLL::::if;;
        ,jLL:;ittt:.............;t:::::,,,....iGEKKKf::::tj;;
        ,fLL;::;;i:..............;:::,,....:fftGKKKEt::::ff;;
        .tiit:::::;itti;::,,,,,,,,,,,:;iiiiiff;;fLLj::::tLf::

                            %cHSL %ccreated by %c@tsukiseele%c - ${new Date().getFullYear()}
  
                            https://github.com/tsukiseele/HSL`;

  console.log(
    ascii,
    "color: #5692ab",
    "color: #5692ab",
    "color: black",
    "color: #77428D",
    "color: black"
  );
  // --primary: rgba(139, 207, 222, 1);
  // --primary-dark: rgba(49, 98, 135, 1);
};
