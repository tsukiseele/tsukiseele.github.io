// import Vue from 'vue'
// import APlayer from '@moefe/vue-aplayer';
// export default defineNuxtPlugin(nuxtApp => {
//   Vue.use(APlayer, {
//     defaultCover: '',
//     productionTip: true,
//   });
// })
